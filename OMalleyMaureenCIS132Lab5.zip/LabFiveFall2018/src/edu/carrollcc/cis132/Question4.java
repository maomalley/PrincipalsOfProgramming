package edu.carrollcc.cis132;

/**
 * Question 4 [5 BONUS Points] - TRY IT it won't count against you!
 *
 * Write a Rectangle Class with three fields that has a constructor with three parameters, 
 *  integers width and length
 *  character drawChar
 * The class will have a method called printOutline that prints a rectangle to the 
 * console that is the outline based on the dimensions width and length.
 * The method will use the character drawChar as its outline character. The method
 * should use nested for loops to print the output.
 * 
 * The main method will demonstrate this class by asking the user for width, length and 
 * a draw character. It will call the constructor with these values and then
 * draw a rectangle outline to the console.
 * Input Validation: Do not allow the user to enter negative numbers for length and width.
 * Loop until they enter a positive value.
 * 
 * Example Output 1:
 * Please enter a positive integer width: 
 * 4
 * Please enter a positive integer length:
 * 5
 * Please enter a character for your drawing:
 * $
 * 
 * $$$$
 * $  $
 * $  $
 * $  $
 * $$$$
 * 
 * Example Output 2:
 * Please enter a positive integer width: 
 * -1
 * INVALID - enter a positive integer width:
 * 6
 * Please enter a positive integer length:
 * -8
 * INVALID - enter a positive integer length:
 * 10
 * Please enter a character for your drawing:
 * !
 * 
 * !!!!!!
 * !    !
 * !    !
 * !    !
 * !    !
 * !    !
 * !    !
 * !    !
 * !    !
 * !!!!!!
 * 
 * @author Maureen OMalley
 */
public class Question4 {

    public static void main(String[] args) {
        
       //TODO: Demonstrate your class here 
       //math.pow
    }
   
}
