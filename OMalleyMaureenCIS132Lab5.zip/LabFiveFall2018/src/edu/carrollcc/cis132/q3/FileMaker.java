/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.carrollcc.cis132.q3;

/**
 *
 * @author Maureen OMalley
 */
public class FileMaker {
    private String file;    // Field to hold the fileName String
    
    public FileMaker(String userFile) {
        file = userFile;
    }
    
    public String removeVowels(String userFile) {
        userFile.charAt(0);
        int x = 0;
        int len = userFile.length();
        while (x < len) {
            // Do something with this character
            userFile.charAt(x);
            x++;
        }
        return userFile;
    }
    
    public String excitify(String userFile) {
        userFile = userFile.replaceAll("[.]", "!");
        return userFile;
    }
    
    public String uppercasify(String userFile) {
        userFile = userFile.replaceAll("[abcdefghijklmnopqrstuvwxyz]", 
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        return userFile;
    }
}
