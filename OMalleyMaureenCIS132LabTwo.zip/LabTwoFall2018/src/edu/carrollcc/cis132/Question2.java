package edu.carrollcc.cis132;
/**
 * Question 2 [10 Points].
 * The following code has errors with unfortunate consequences.  Find and 
 * fix the errors without changing the print statement.
 * 
 * @author Maureen OMalley
 */
public class Question2 {
    
    public static void main(String[] args){
        //TODO Fix the code!
        float correctAnswers = 17;
        float questionCount = 20;

        float score = correctAnswers/questionCount;

        //Don't change this statement
        System.out.println("You received a score of " + score * 100 + ".");
    }
    
}