package BlackJack;

/**
 * This class contains the enumerated type Value, which contains all possible
 * card values. Each enumeration will be matched with a suit to produce 52 cards
 * in the Deck class.
 * @author Maureen OMalley
 */
public enum Value {
    TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE
}
