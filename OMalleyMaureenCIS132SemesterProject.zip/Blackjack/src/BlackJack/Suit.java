package BlackJack;

/**
 * This class contains the enumerated type Suit, which holds all possible 
 * suit values.
 * @author Maureen OMalley
 */
public enum Suit {
    HEART, SPADE, DIAMOND, CLUB
}
