package BlackJack;

import java.util.ArrayList; /* REQ 9 */
import java.util.Random;    /* REQ 3C */

/**
 * The Deck class contains 
 * REQ 8
 * @author Maureen OMalley
 */
public class Deck {

    /* REQ 9 */
    private ArrayList<Card> cards;

    /**
     * Create a new deck of cards
     */
    public Deck() {
        this.cards = new ArrayList<Card>();
    }

    /**
     * Add 52 cards to the deck
     */
    public void createDeck() {
        for (Suit cardSuit : Suit.values()) {
            for (Value cardValue : Value.values()) {
                this.cards.add(new Card(cardSuit, cardValue));
            }
        }
    }
    
    /**
     * Creates a new arraylist to hold shuffled cards, randomly selects
     * a card from the original deck, and copies that card into new deck.
     * REQ 3C
     */
    public void shuffle() {
        ArrayList<Card> shuffledDeck = new ArrayList<Card>();
        
        Random random = new Random();
        
        int randomCardIndex = 0;
        int originalSize = this.cards.size();
        for (int i = 0; i < originalSize; i++) {
            randomCardIndex = random.nextInt((this.cards.size() - 1 - 0) + 1) + 0;
            shuffledDeck.add(this.cards.get(randomCardIndex));
            this.cards.remove(randomCardIndex);
        }
        this.cards = shuffledDeck;
    }
    
    /**
     * Removes that card that was passed in from the arraylist.
     * @param i index that is passed in
     */
    public void removeCard(int i) {
        this.cards.remove(i);
    }

    /**
     * Gets the card that is passed in from the arraylist.
     * REQ 7
     * @param i index passed in
     * @return ArrayList .get() method returns the index passed in
     */
    public Card getCard(int i) {
        return this.cards.get(i);
    }

    /**
     * Adds a card to the cards arraylist.
     * @param addCard a card from the Card class
     */
    public void addCard(Card addCard) {
        this.cards.add(addCard);
    }

    /**
     * Adds a card to the cards arraylist and removed it from the passed in deck.
     * @param deckParameter the deck that is passed in.
     */
    public void draw(Deck deckParameter) {
        this.cards.add(deckParameter.getCard(0));
        deckParameter.removeCard(0);
    }
    
    /**
     * toString method to print out the deck.
     * @return a string that holds the deck.
     */
    public String toString() {
        String cardListOutput = "";
        int i = 0;
        for (Card getCard : this.cards) {
            cardListOutput += "\n" + getCard.toString();
            i++;
        }
        return cardListOutput;
    }
    
    /**
     * Puts cards in the passed in deck and then empties out the deck.
     * @param moveTo the passed in deck
     */
    public void toDeck(Deck moveTo) {
        int thisDeckSize = this.cards.size();
        //put cards in moveTo deck
        for (int i = 0; i < thisDeckSize; i++) {
            moveTo.addCard(this.getCard(i));
        }
        //empty out the deck
        for (int i = 0; i < thisDeckSize; i++) {
            this.removeCard(0);
        }
    }
    
    /**
     * Gets the size of the arraylist.
     * @return integer representing deck size
     */
    public int deckSize() {
        return this.cards.size();
    }

    /**
     * cardsValue calculates the total value of the deck.
     * REQ 5
     * @return integer representing the total value of the deck.
     */
    public int cardsValue() {
        int totalValue = 0;
        int aces = 0;
        //For every card in the deck
        for (Card getCard : this.cards) {
            /* REQ 5 Switch of possible values */
            switch (getCard.getValue()) {
                case TWO:
                    totalValue += 2;
                    break;
                case THREE:
                    totalValue += 3;
                    break;
                case FOUR:
                    totalValue += 4;
                    break;
                case FIVE:
                    totalValue += 5;
                    break;
                case SIX:
                    totalValue += 6;
                    break;
                case SEVEN:
                    totalValue += 7;
                    break;
                case EIGHT:
                    totalValue += 8;
                    break;
                case NINE:
                    totalValue += 9;
                    break;
                case TEN:
                    totalValue += 10;
                    break;
                case JACK:
                    totalValue += 10;
                    break;
                case QUEEN:
                    totalValue += 10;
                    break;
                case KING:
                    totalValue += 10;
                    break;
                case ACE:
                    aces += 1;
                    break;
            }
        }
        
        for (int i = 0; i < aces; i++) {
            /* REQ 4 determine ace worth */
            if (totalValue > 10) {
                totalValue += 1;
            } else {
                totalValue += 11;
            }
        }
        return totalValue;
    }    
}
