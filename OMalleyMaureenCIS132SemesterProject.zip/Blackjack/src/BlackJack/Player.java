package BlackJack;

import java.io.*;

/**
 * The Player class contains a method that is used to append the outcome of
 * the match to a file.
 * @author Maureen OMalley
 */
public class Player {
    /**
     * The recordMatch method appends the match outcome to the MatchRecord.txt 
     * file depending on the integer that is passed to the method.
     * REQ 10
     * @param outcome integer representing either loss, win, or tie
     * @throws IOException 
     */
    public void recordMatch(int outcome) throws IOException {
        FileWriter fwriter = new FileWriter("MatchRecord.txt", true);
        PrintWriter outputFile = new PrintWriter(fwriter);
        
        if (outcome == 0) {
            outputFile.println("Loss");
        } else if (outcome == 1) {
            outputFile.println("Win");
        } else {
            outputFile.println("Tie");
        }
        
        outputFile.close();
    }
}
