package BlackJack;

import java.io.*;
import java.util.Scanner;

/**
 * This class contains the main method in which the game will be played.
 *
 * @author Maureen OMalley
 */
public class BlackJack {

    public static void main(String[] args) throws IOException {
        /* REQ 1 */
        System.out.println("Maureen O\'Malley\n");

        Deck playingDeck = new Deck();
        playingDeck.createDeck();
        playingDeck.shuffle();

        Deck playerCards = new Deck();

        Deck dealerCards = new Deck();

        Scanner keyboard = new Scanner(System.in);

        /* REQ 2 */
        System.out.println("To start playing BlackJack, please enter your name: ");
        String username = keyboard.nextLine();
        /* REQ 3A, REQ 6 */
        while (username.equalsIgnoreCase("Dealer")) {
            System.out.println("The name \"Dealer\" is already taken. "
                    + "Please choose another name: ");
            username = keyboard.nextLine();
        }
        System.out.println("Welcome to BlackJack, " + username + "!\n");

        Player match = new Player();
        int playAgain = 1;
        while (playAgain == 1) {
            //Player gets two cards
            playerCards.draw(playingDeck);
            playerCards.draw(playingDeck);

            //Dealer gets two cards
            dealerCards.draw(playingDeck);
            dealerCards.draw(playingDeck);

            boolean endRound = false;
            boolean loopControl = true;
            while (loopControl == true) {
                //Display player cards
                System.out.println("Your current Hand:" + playerCards.toString());

                //Display player hand value
                System.out.println("Your hand\'s current value: " 
                        + playerCards.cardsValue());

                //Display dealer cards
                System.out.println("Dealer\'s current Hand: " 
                        + dealerCards.getCard(0).toString() + " and a hidden card.");

                /* REQ 2 ask if player will hit or stand */
                System.out.println("Would you like to (1)HIT or (2)STAND?");
                int response = keyboard.nextInt();
                
                while(response != 1 && response != 2) {
                    System.out.println("Error: please enter either 1 or 2.");
                    System.out.println("Would you like to (1)HIT or (2)STAND?");
                    response = keyboard.nextInt();
                }
                
                /* REQ 4 if statement for when hit is selected */
                if (response == 1) {
                    playerCards.draw(playingDeck);
                    System.out.println("You drew a: " 
                        + playerCards.getCard(playerCards.deckSize() - 1).toString());
                    //if statement to bust if they go over 21
                    if (playerCards.cardsValue() > 21) {
                        System.out.println("Bust. Currently valued at: " 
                                            + playerCards.cardsValue());
                        /* REQ 10 call the recordMatch function to record match outcome */
                        match.recordMatch(0);
                        endRound = true;
                        loopControl = false;
                    }
                }

                //Stand
                if (response == 2) {
                    loopControl = false;
                }

            }

            //Reveal Dealer Cards
            System.out.println("Dealer\'s Cards:" + dealerCards.toString());
            //if statement to determine if dealer has more points than player
            if ((dealerCards.cardsValue() > playerCards.cardsValue()) && endRound == false) {
                System.out.println("The Dealer beat you " + dealerCards.cardsValue() 
                        + " to " + playerCards.cardsValue());
                match.recordMatch(0);
                endRound = true;
            }
            //Dealer hits at 16 stands at 17
            while ((dealerCards.cardsValue() < 17) && endRound == false) {
                dealerCards.draw(playingDeck);
                System.out.println("Dealer drew: " 
                    + dealerCards.getCard(dealerCards.deckSize() - 1).toString());
            }
            //Display value of dealer
            System.out.println("The Dealer\'s hand is valued at: " + dealerCards.cardsValue());
            //Determine if dealer busted
            if ((dealerCards.cardsValue() > 21) && endRound == false) {
                System.out.println("The Dealer Busts. You win!");
                match.recordMatch(1);
                endRound = true;
            }
            
            //Determine if tie
            if ((dealerCards.cardsValue() == playerCards.cardsValue()) && endRound == false) {
                System.out.println("It was a Tie.");
                match.recordMatch(2);
                endRound = true;
            }
            //Determine if player wins
            if ((playerCards.cardsValue() > dealerCards.cardsValue()) && endRound == false) {
                System.out.println("You win!");
                match.recordMatch(1);
                endRound = true;
            } else if (endRound == false) //dealer wins
            {
                match.recordMatch(0);
                System.out.println("Dealer wins.");
            }

            //End of hand - put cards back in deck
            playerCards.toDeck(playingDeck);
            dealerCards.toDeck(playingDeck);
            System.out.println("End of Hand.\n");

            /* REQ 2 determine if player wants to play again */
            System.out.println("Would you like to play again?\n(1)YES\t(2)NO");
            playAgain = keyboard.nextInt();
            while (playAgain != 1 && playAgain != 2) {
                System.out.println("Error: please enter either 1 if you WOULD "
                        + "like to play again, or 2 if you would like to QUIT.");
                playAgain = keyboard.nextInt();
            }
        }
        System.out.println("Goodbye!");
    }
}
