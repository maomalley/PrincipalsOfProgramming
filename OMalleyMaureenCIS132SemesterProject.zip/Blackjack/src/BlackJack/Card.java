package BlackJack;

/**
 * The Card class contains methods to get the Value and Suit of cards.
 * REQ 8
 * @author Maureen OMalley
 */
public class Card {

    private Suit suit;
    private Value value;

    /**
     * Constructor to set card suit and card value.
     * @param suit
     * @param value 
     */
    public Card(Suit suit, Value value) {
        this.suit = suit;
        this.value = value;
    }

    /**
     * toString method for printing out the card's suit and value.
     * @return String containing the card suit and value.
     */
    public String toString() {
        return this.suit.toString() + " " + this.value.toString();
    }

    /**
     * Getter for the value
     * @return the card value
     */
    public Value getValue() {
        return this.value;
    }

    /**
     * Getter for the suit
     * @return the card suit
     */
    public Suit getSuit() {
        return this.suit;
    }    
}