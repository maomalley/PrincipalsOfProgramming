package edu.carrollcc.cis132.q2;

/**
 * This class contains two methods which can be used as tools on arrays --
 * selectionSort and searchString.
 *
 * @author Maureen OMalley
 */
public class ArrayTools {

    /**
     * The selection sort method accepts a String array and sorts it
     * alphabetically. Note that these changes happen to the array that is
     * passed in and NOT to a copy.
     *
     * @param selectionArray the array that will be selection sorted
     */
    public void selectionSort(String[] selectionArray) {
        for (int i = 0; i < selectionArray.length - 1; ++i) {
            int minIndex = i;
            for (int j = i + 1; j < selectionArray.length; ++j) {
                if (selectionArray[j].compareTo(selectionArray[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            String temporaryArray = selectionArray[i];
            selectionArray[i] = selectionArray[minIndex];
            selectionArray[minIndex] = temporaryArray;
        }
    }

    /**
     * The sequentialSearch method accepts a String which will be used to look
     * for a match in the searchArray which is also passed in. It returns -1 if
     * no matches appear, or it returns the element in which a match was found.
     *
     * @param searchString the string to be matched to the searchArray.
     * @param searchArray the array to be searched.
     * @return integer representing the element where a match was found.
     */
    public int sequentialSearch(String searchString, String[] searchArray) {
        int index;
        int element;
        boolean found;

        index = 0;

        element = -1;
        found = false;

        while (!found && index < searchArray.length) {
            if (searchArray[index].equalsIgnoreCase(searchString)) {
                found = true;
                element = index;
            }

            index++;
        }

        return element;
    }
}
