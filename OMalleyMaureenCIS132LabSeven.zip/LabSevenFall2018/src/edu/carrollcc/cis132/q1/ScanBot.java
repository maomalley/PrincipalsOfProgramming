package edu.carrollcc.cis132.q1;

/**
 * This class contains a private array correctAnswers as well as three methods
 * to calculate a student's correct answers, grade percent, and letter grade for
 * the exam.
 *
 * @author Maureen O'Malley
 */
public class ScanBot {

    //field to hold correct answers in array
    private char[] correctAnswers = {'B', 'D', 'A', 'A', 'C', 'A', 'B', 'A',
        'C', 'D', 'B', 'C', 'D', 'A', 'D', 'C', 'C', 'B', 'D', 'A'};

    /**
     * The totalCorrect method compares the values of two parallel arrays to
     * find which studentAnswers array values match the correctAnswers array
     * values.
     *
     * @param studentAnswers character array containing the student's answers
     * @return integer correctCounter representing the number of questions
     * correctly answered
     */
    public int totalCorrect(char[] studentAnswers) {
        int correctCounter = 0;
        int index = 0; //Loop control variable

        while (index < studentAnswers.length) {
            if (studentAnswers[index] == correctAnswers[index]) {
                correctCounter++;
                index++;
            } else {
                index++;
            }
        }

        return correctCounter;
    }

    /**
     * The percentGrade method uses the totalCorrect method to divide the number
     * of correct answers by 20, the total number of questions, and multiply
     * that number by 100 to return a percentage.
     *
     * @param studentAnswers character array containing the student's answers
     * @return double gradePercent representing the student's exam score
     * percentage
     */
    public double percentGrade(char[] studentAnswers) {
        //numCorrectAnswers uses the totalCorrect method in this class
        double numCorrectAnswers = totalCorrect(studentAnswers);
        //gradePercent is numCorrectAnswers divided by the number of questions
        //then multiplied by 100
        double gradePercent = (double) (numCorrectAnswers / 20) * (double) (100);

        return gradePercent;
    }

    /**
     * The letterGrade method accepts a character array and uses the
     * percentGrade method to assign a letter grade depending on the grade
     * percentage earned.
     *
     * @param studentAnswers character array containing the student's exam
     * answers
     * @return character gradeLetter representing the letter grade a student
     * earned for the exam
     */
    public char letterGrade(char[] studentAnswers) {
        //get the grade percentage from the percentGrade method in this class
        double gradePercentage = percentGrade(studentAnswers);
        //initialize character variable gradeLetter
        char gradeLetter;

        //assign a grade depending on the gradePercentage
        //else statement shouldn't occur.
        if (gradePercentage >= 90) {
            gradeLetter = 'A';
        } else if (gradePercentage < 90 && gradePercentage >= 80) {
            gradeLetter = 'B';
        } else if (gradePercentage < 80 && gradePercentage >= 70) {
            gradeLetter = 'C';
        } else if (gradePercentage < 70 && gradePercentage >= 60) {
            gradeLetter = 'D';
        } else if (gradePercentage < 60) {
            gradeLetter = 'F';
        } else {
            gradeLetter = '?';
        }

        return gradeLetter;
    }
}
