package edu.carrollcc.cis132;

/**
 * Question 4 [20 Points]
 * Write a program with the class name "Question4" that will display your:
 * 1. Name on the first line.
 * 2. Major on the second line.
 * 3. Favorite candy/snack on the third line.
 * 4. Favorite hobby/activity on the fourth line.
 * 5. Thing you are proud of on the fifth line.
 * 
 * Add a comment to the top of the program with today's date.
 * Test your program by compiling and running it!
 * 
 * @author Maureen OMalley
 */

// August 29, 2018
public class Question4 {
    
    public static void main(String[] args){
        System.out.println("Maureen O\'Malley");
        System.out.println("Major: Computer Programming");
        System.out.println("Favorite snack: Macarons");
        System.out.println("Favorite hobby: Painting");
        System.out.println("I am proud to own my cat!");
    }
    
}