package edu.carrollcc.cis132;

/**
 * Question 1 [10 Points]
 * Write a statement in the main function to print "I love programming!" on a 
 * line to the console.
 * Test your program by compiling and running it.
 * 
 * @author Maureen OMalley
*/
public class Question1 {
    
    public static void main(String[] args)
    {
        System.out.println("I love programming!");
    }
}

