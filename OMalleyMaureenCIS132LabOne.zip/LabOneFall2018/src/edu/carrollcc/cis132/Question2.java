package edu.carrollcc.cis132;
/**
 * Question 2 [10 Points] The following program has formatting problems. 
 * Use "escape sequences" to add end of lines and tabs to the output. 
 * The output should display as follows:
 * 
 * These are my favorite pets:
 *      Dogs
 *      Cats
 *      Tropical Fish
 *
 * Test your program by compiling and running it.
 * @author Maureen OMalley
 */
public class Question2 
{

    public static void main(String[] args) 
    {
        System.out.print("These are my favorite pets:\n");
        System.out.print("\tDogs\n");
        System.out.print("\tCats\n");
        System.out.print("\tTropical Fish\n");   
    }
}
