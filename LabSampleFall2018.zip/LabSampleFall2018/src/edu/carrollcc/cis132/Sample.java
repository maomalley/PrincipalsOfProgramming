
package edu.carrollcc.cis132;

/**
 *
 * @author WRITE YOUR NAME HERE
 */
public class Sample {
    public static void main(String[] args){
    
        System.out.println("This is a class to help demonstrate exporting your "
                + "project to a .zip file.");
        
    }
}
